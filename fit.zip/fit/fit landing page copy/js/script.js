var owl = $('.owl-carousel');
owl.owlCarousel({
    loop:true,
    nav:true,
    dots:false,
    autoplay:false,
    // autoplayTimeout:3000,
    responsiveClass:true,
    margin:10,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },            
        767:{
            items:2
        },
        1000:{
            items:3,
            
        }

    }
});

// video pop-up
document.getElementById('playButton').addEventListener('click', function() {
    document.getElementById('videoPopup').style.display = 'block';
    document.getElementById('videoPlayer').play();
  });
  
  document.getElementById('closeButton').addEventListener('click', function() {
    document.getElementById('videoPopup').style.display = 'none';
    document.getElementById('videoPlayer').pause();
  });